online stranka:
https://www.stud.fit.vutbr.cz/~xkeprt03/ITW2/

Autor: Ondřej Keprt
xlogin: xkeprt03